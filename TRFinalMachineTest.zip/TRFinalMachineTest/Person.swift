//
//  Person.swift
//  TRFinalMachineTest
//
//  Created by Focaloid on 15/02/17.
//  Copyright © 2017 Focaloid. All rights reserved.
//

import Foundation
import CoreData


class Person: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
