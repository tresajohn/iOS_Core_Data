//
//  TRLoginTableViewController.swift
//  TRFinalMachineTest
//
//  Created by Focaloid on 15/02/17.
//  Copyright © 2017 Focaloid. All rights reserved.
//

import UIKit
import CoreData

var people = [NSManagedObject]()
var firstName = [String]()
var secondName = [String]()
var phoneNo = [String]()
var userName = [String]()
var password = [String]()

class TRLoginTableViewController: UITableViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginbutton: UIButton!
    @IBOutlet weak var signupbutton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    
    var fName : String?
    var sName : String?
    var phone : String?
    var email : String?
    var username : String?
    var pwd : String?
    var status = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundView = UIImageView(image: UIImage(named: "ic_bg"))
        title = "User Login"
        imageView.layer.cornerRadius = 50
        imageView.layer.masksToBounds = true
        
//        loginbutton.layer.borderColor = UIColor.blueColor().CGColor
//        loginbutton.layer.borderWidth = 1
//        signupbutton.layer.borderColor = UIColor.blueColor().CGColor
//        signupbutton.layer.borderWidth = 1
    }
    
    @IBAction func loginButon(sender: UIButton) {
        
        //Fetching Data
        
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedObjectContext = appDelegate.managedObjectContext
        let predicate = NSPredicate (format:"username = %@" ,usernameTextField.text!)
        let fetchRequest = NSFetchRequest ( entityName: "Person")
        fetchRequest.predicate = predicate
        do{
            let fetchResult = try managedObjectContext.executeFetchRequest(fetchRequest) as! [Person]
            if fetchResult.count > 0 
            {
                for bEntity in fetchResult {
                    let person =  bEntity
                        username = person.valueForKey("username") as? String
                        pwd = person.valueForKey("password") as? String
                        fName = person.valueForKey("firstname") as? String
                        sName = person.valueForKey("secondname") as? String
                        phone = person.valueForKey("phoneno") as? String
                        email = person.valueForKey("email") as? String
                    }
                    if fName == usernameTextField.text && pwd == passwordTextField.text
                        {
                            let homeController = storyboard?.instantiateViewControllerWithIdentifier("homeVCID") as! TRHomePageTableViewController
                            homeController.firstNameHome = fName
                            homeController.secondNameHome = sName
                            homeController.phoneNumberHome = phone
                            homeController.emailIDHome = email
                            navigationController?.pushViewController(homeController, animated: true)
                    }
                    else
                    {
                        let confirmActionSheetController: UIAlertController = UIAlertController(title: "Confirm", message: "Invalid User", preferredStyle: .Alert)
                        let okAction: UIAlertAction = UIAlertAction(title: "OK", style: .Default) { action -> Void in
                        }
                        confirmActionSheetController.addAction(okAction)
                        self.presentViewController(confirmActionSheetController, animated: true, completion: nil)
                    }
            }
            else
            {
                let confirmActionSheetController: UIAlertController = UIAlertController(title: "Confirm", message: "Invalid User", preferredStyle: .Alert)
                let okAction: UIAlertAction = UIAlertAction(title: "OK", style: .Default) { action -> Void in }
                confirmActionSheetController.addAction(okAction)
                self.presentViewController(confirmActionSheetController, animated: true, completion: nil)
            }
        }
        catch{
            print(error)
        }
    }
    
    @IBAction func signupButton(sender: UIButton) {
        let signupController = storyboard?.instantiateViewControllerWithIdentifier("signupVCID")
        navigationController?.pushViewController(signupController!, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
