//
//  TRSignupPageTableViewController.swift
//  TRFinalMachineTest
//
//  Created by Focaloid on 15/02/17.
//  Copyright © 2017 Focaloid. All rights reserved.
//

import UIKit
import CoreData

class TRSignupPageTableViewController: UITableViewController {

    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var secondNameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundView = UIImageView(image: UIImage(named: "ic_bg"))
        title = "New User"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func signupButton(sender: UIButton) {
        
        //Validation Check
        
        if (validateName(firstNameTextField.text!) == false){
            return alertMessage("Invalid Name")
        }
        
        if (validateName(secondNameTextField.text!) == false){
            return alertMessage("Invalid Name")
        }

        if (validateMobileNumber(phoneTextField.text!) == false){
            return alertMessage("Invalid Mobile Number")
        }
        
        if (validateName(usernameTextField.text!) == false){
            return alertMessage("Invalid Name")
        }
        
        if (validateEmail(emailTextField.text!) == false){
            return alertMessage("Invalid Email ID")
        }
        
        if (validatePassword(passwordTextField.text!) == false){
            return alertMessage("Invalid Password")
        }
        
        //Saving Data
        
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        let entity =  NSEntityDescription.entityForName("Person", inManagedObjectContext:managedContext)
        let person = NSManagedObject(entity: entity!, insertIntoManagedObjectContext: managedContext)
        person.setValue(firstNameTextField.text, forKey: "firstname")
        person.setValue(secondNameTextField.text, forKey: "secondname")
        person.setValue(phoneTextField.text, forKey: "phoneno")
        person.setValue(emailTextField.text, forKey: "email")
        person.setValue(usernameTextField.text, forKey: "username")
        person.setValue(passwordTextField.text, forKey: "password")
        
        do {
            try managedContext.save()
            people.append(person)
        }
        catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    //Name Validation
    
    func validateName(testString : String)->Bool
    {
        let whitespaceSet = NSCharacterSet.whitespaceCharacterSet()
        if !testString.stringByTrimmingCharactersInSet(whitespaceSet).isEmpty
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    //Phone Validation
    
    func validateMobileNumber(testString : String)->Bool
    {
        if testString.characters.count == 10
        {
            if (Int(testString) != nil)
            {
                return true
            }
            else
            {
                return false
            }
        }
        else
        {
            return false
        }
    }
    
    //Email Validation
    
    func validateEmail(testString : String)-> Bool
    {
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        if emailTest.evaluateWithObject(testString)
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    //Password Validation
    
    func validatePassword(testString : String)-> Bool
    {
        if testString.characters.count <= 7 {
            return false
        }
        else{
            return true
        }
    }
    
    //Alert Function
    
    func alertMessage(alertMessage : String){
        let confirmActionSheetController: UIAlertController = UIAlertController(title: "Error", message: alertMessage, preferredStyle: .Alert)
        let okAction: UIAlertAction = UIAlertAction(title: "OK", style: .Default) { action -> Void in
        }
        confirmActionSheetController.addAction(okAction)
        self.presentViewController(confirmActionSheetController, animated: true, completion: nil)
    }

}
