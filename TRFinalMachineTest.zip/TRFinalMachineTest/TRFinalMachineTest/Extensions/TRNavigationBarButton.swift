//
//  TRNavigationBarButton.swift
//  TRFinalMachineTest
//
//  Created by Focaloid on 15/02/17.
//  Copyright © 2017 Focaloid. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    
    func leftNavigationButton()->UIButton {
        let image = UIImage(named: "ic_save") as UIImage?
        let button   = UIButton(type: UIButtonType.Custom) as UIButton
        button.setImage(image, forState: .Normal)
        button.frame = CGRectMake(0, 0, 30, 30)
        button.addTarget(self, action: #selector(UIViewController.rightAction), forControlEvents: .TouchUpInside)
        
        //Set Left Bar Button item
        let rightBarButton = UIBarButtonItem()
        rightBarButton.customView = button
        self.navigationItem.rightBarButtonItem = rightBarButton
        return button
    }
    
    func rightAction() {
    }
    
    func leftAction() {
    }
}
