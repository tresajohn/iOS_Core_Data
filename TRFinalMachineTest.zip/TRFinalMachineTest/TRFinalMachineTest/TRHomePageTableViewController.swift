//
//  TRHomePageTableViewController.swift
//  TRFinalMachineTest
//
//  Created by Focaloid on 15/02/17.
//  Copyright © 2017 Focaloid. All rights reserved.
//

import UIKit
import CoreData

class TRHomePageTableViewController: UITableViewController {

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var secondName: UITextField!
    @IBOutlet weak var phoneNo: UITextField!
    @IBOutlet weak var emailID: UITextField!
    
    var firstNameHome : String?
    var secondNameHome : String?
    var phoneNumberHome : String?
    var emailIDHome : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundView = UIImageView(image: UIImage(named: "ic_bg"))
        firstName.text = firstNameHome
        secondName.text = secondNameHome
        phoneNo.text = phoneNumberHome
        emailID.text = emailIDHome
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    } 
}
