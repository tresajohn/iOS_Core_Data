//
//  Person+CoreDataProperties.swift
//  TRFinalMachineTest
//
//  Created by Focaloid on 15/02/17.
//  Copyright © 2017 Focaloid. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Person {

    @NSManaged var firstname: String?
    @NSManaged var secondname: String?
    @NSManaged var phoneno: String?
    @NSManaged var username: String?
    @NSManaged var password: String?
    @NSManaged var email: String?

}
